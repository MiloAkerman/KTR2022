package orbitalstriketherobot;
import battlecode.common.*;

enum SageRole {

}

//TODO: Sage logic
public class Sage extends Unit {
    static SageRole currRole;
    public static void setup() throws GameActionException {
        readPulse();
    }

    public static void run() throws GameActionException {

    }
}
