package orbitalstriketherobot;

//TODO: Lab logic
public class Laboratory {
    public static void setup() {

    }
    public static void run() {

    }
}
